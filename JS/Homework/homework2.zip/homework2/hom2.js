/*1*/
let mac = [12324, true, 'jne', '1234', 123, 'window', 'cat', 'dog', 'skay', 5666888];
console.log(mac);
console.log(mac[0]);
console.log(mac[1]);
console.log(mac[2]);
console.log(mac[3]);
console.log(mac[4]);
console.log(mac[5]);
console.log(mac[6]);
console.log(mac[7]);
console.log(mac[8]);
console.log(mac[9]);
/*
2*/
let book1={
    title: 'Harry Potter',
    pageCount: 350,
    genre: 'Fantasy',

}
console.log(book1);
let book2={
    title: 'docter',
    pageCount: 250,
    genre: 'Biography',

}
console.log(book2);
let book3={
    title: 'cafe',
    pageCount: 150,
    genre: 'Fantasy',

}
console.log(book3);

/*
3*/
book1.author = ['name:"Rowling"', 'age:57'];
console.log(book1);
book2.author = ['name:"Levi"', 'age:50'];
book3.author = ['name:"Streleki"', 'age:40'];
console.log(book2);
console.log(book3);
/*
 4*/

let face=['user1','user2','user3','user4','user5','user6','user7','user8','user9','user10',]
let user1={
    name:'olga',
    username:'olgam',
    password:'12345'
}
console.log(user1.password);
let user2={
    name:'vasya',
    username:'vasyana',
    password:'fs24124'
}
console.log(user2.password);
let user3={
    name:'inna',
    username:'innakrk',
    password:'ssrfwe83432'
}
console.log(user3.password);
let user4={
    name:'dima',
    username:'dimadd',
    password:'532fdsg'
}
console.log(user4.password);
let user5={
    name:'nika',
    username:'nikasaf',
    password:'sfew35345'
}
console.log(user5.password);
let user6={
    name:'bodya',
    username:'bodya',
    password:'dg43346'
}
console.log(user6.password);
let user7={
    name:'sveta',
    username:'svetagds',
    password:'323kjs'
}
console.log(user7.password);
let user8={
    name:'petja',
    username:'petjasfa',
    password:'3523knv'
}
console.log(user8.password);
let user9={
    name:'valya',
    username:'vakyadfds',
    password:'35fndsgn32'
}
console.log(user9.password);
let user10={
    name:'alisa',
    username:'cat',
    password:'1ff355ger'
}
console.log(user10['password']);